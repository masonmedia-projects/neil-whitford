<div 
class="absolute z-0 left rellax <?php echo $shapeBig; ?>" 
data-rellax-speed="1"></div>
<div 
class="absolute z-0 left rellax <?php echo $shapeSmall; ?>" data-rellax-speed="2"></div>