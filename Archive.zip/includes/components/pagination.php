<a 
class="d-inline" 
href="<?php echo $prevUrl; ?>.php">
    <h1 class="display-1 font-weight-bold">Prev.</h1>
</a>
<a 
class="d-inline ml-auto" 
href="<?php echo $nextUrl; ?>.php">
    <h1 class="display-1 font-weight-bold">Next.</h1>
</a>