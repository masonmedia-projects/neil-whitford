// this is here for webpack to expose SwupTheme as window.SwupTheme
import SwupTheme from './src/index.js';
module.exports = SwupTheme;
